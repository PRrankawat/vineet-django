from django.apps import AppConfig


class UserattandanceConfig(AppConfig):
    name = 'userAttandance'
