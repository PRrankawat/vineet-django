from django.apps import AppConfig


class StockdetailsConfig(AppConfig):
    name = 'stockDetails'
