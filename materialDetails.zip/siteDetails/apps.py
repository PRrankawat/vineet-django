from django.apps import AppConfig


class SitedetailsConfig(AppConfig):
    name = 'siteDetails'
