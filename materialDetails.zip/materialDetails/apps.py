from django.apps import AppConfig


class MaterialdetailsConfig(AppConfig):
    name = 'materialDetails'
